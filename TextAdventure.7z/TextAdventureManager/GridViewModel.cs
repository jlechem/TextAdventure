﻿namespace TextAdventureManager
{
    internal class GridViewModel
    {
    }
}