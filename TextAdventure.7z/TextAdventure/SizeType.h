#pragma once

enum SizeType
{
	small,
	medium,
	large,
	extraLarge,
	infinite
};