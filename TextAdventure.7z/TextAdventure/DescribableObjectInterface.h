#pragma once

#include "stdafx.h"

class DescribableObjectInterface
{
public:
	DescribableObjectInterface();
	~DescribableObjectInterface();



protected:
	string _description;

private:

};