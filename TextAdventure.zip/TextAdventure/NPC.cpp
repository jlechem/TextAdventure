/*
	NPC.cpp
	Created By:			Justin LeCheminant
	Created On:			12-21-2017
	Last Modified:		12-21-2017
	Last Modified By:	Justin LeCheminant

	Notes: Implementation of the NPC class.

*/

#include "stdafx.h"
#include "NPC.h"


NPC::NPC()
{
}


NPC::~NPC()
{
}
