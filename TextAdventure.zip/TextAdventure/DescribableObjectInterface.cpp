#include "stdafx.h"
#include "DescribableObjectInterface.h"


DescribableObjectInterface::DescribableObjectInterface()
{
}


DescribableObjectInterface::~DescribableObjectInterface()
{
}
